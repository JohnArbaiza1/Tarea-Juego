﻿
using var game = new TareaJuego.Game1();
game.Run();
